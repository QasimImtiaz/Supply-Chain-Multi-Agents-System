package set10111.SupplyChain_ontology.elements;

import jade.content.AgentAction;
import jade.core.AID;

public class Assemble implements AgentAction {
	private int numberOfSmartphones; 
	private AID manufacturerAid;
	
	
	
	
}
