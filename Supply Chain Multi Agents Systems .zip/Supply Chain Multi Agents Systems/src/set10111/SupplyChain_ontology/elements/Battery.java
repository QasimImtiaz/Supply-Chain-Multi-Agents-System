package set10111.SupplyChain_ontology.elements;

import jade.content.onto.annotations.Slot;

public class Battery extends Component {
	
}
