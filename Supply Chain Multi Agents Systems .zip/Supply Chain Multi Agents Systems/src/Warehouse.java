
public class Warehouse {

}
